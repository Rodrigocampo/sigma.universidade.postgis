Dados
=================================================

Para o curso, iremos trabalhar com massas de dados simples,
de modo que o aluno consiga compreender os conceitos do PostGIS,
enquanto navegando em sua realidade geoespacial.

Para isto, preparamos uma massa de dados, com municípios e estados (do IBGE) e hidrografia do Brasil (Agência Nacional de Águas). Estes
dados estão na internet de graça, mas colocamos os mesmos aqui para
facilitar a vida do aluno.

* [[Municípios|https://github.com/downloads/george-silva/curso-postgis/municipios.tar.gz]] (84.3mb)

* [[Estados|https://github.com/downloads/george-silva/curso-postgis/uf.tar.gz]] (5.7mb)

* [[Hidrografia|https://github.com/downloads/george-silva/curso-postgis/hidrografia.tar.gz]] (25mb)


Como usar?
-------------------------------------------------

Para os usuários de linux, faça o download através
do navegador do arquivo de interesse e o armazene em
um determinado caminho, exemplo: `/home/george/Desktop/hidrografia.tar.gz`.

A partir deste momento, precisamos descompactar o arquivo. Isto
pode ser feito facilmente através do comando: `tar -xvf /home/george/Desktop/hidrografia.tar.gz` ou então através da
interface gráfica, clicando com o botão direito sobre o arquivo
e escolhendo `Extract Here`.