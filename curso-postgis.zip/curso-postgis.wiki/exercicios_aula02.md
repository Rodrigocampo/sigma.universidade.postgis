# Exercícios Aula 02

1 - Utilizando as funções de construção de geometrias, construa algumas geometrias no psql. Construa pelo menos uma geometria de cada tipo: ponto, linha, polígono, polígono com buracos. Faça este exercício de forma a que cada geometria tenha um SRID válido.

2 - Utilizando as funções de geometrias, construa algumas geometrias no psql. Faça estas geometrias com mais de duas dimensões e tenha certeza que elas possuem um SRID válido.

3 - O que são ```BBOX``` (ou ```MBR```  ou ```envelope```)? Qual é a utilidade dos mesmos para o _PostGIS_?

4 - Quais são os principais tipos de sistemas de coordenadas?

5 - Um sistema de coordenada projetado depende de quais informações para corretamente localizar um ponto na superfície da Terra?

6 - Construa e transforme algumas geometrias. Faça com que a geometria seja construída com um _SRID_ válido e a transforme para outro _SRID_ válido.

7 - Calcule a área e o perímetro em metros da seguinte geometria (```ST_Area``` e ```ST_Perimeter```)

```POLYGON((-48.188 -16.023,-48.188 -15.525,-47.451 -15.525,-47.451 -16.023,-48.188 -16.023))```

8 - Selecione todos os municípios que intersecionam o polígono abaixo:

```POLYGON((-48.188 -16.023,-48.188 -15.525,-47.451 -15.525,-47.451 -16.023,-48.188 -16.023))```

9 - Faça um teste comparativo entre o uso da função ST_Intersects para o exercício acima e o uso do operador &&. Qual método levou menos tempo? Qual método foi mais preciso? Os resultados foram semelhantes?

10 - Selecione todos os municípios que estão à esquerda de Uberlândia (à oeste - dica: use operadores);

11 - Como podemos fazer uma conversão entre ```GEOMETRY``` e ```GEOGRAPHY```?

12 - Calcule a soma dos comprimentos da hidrografia que cruzam o município de Uberlândia - MG em km.