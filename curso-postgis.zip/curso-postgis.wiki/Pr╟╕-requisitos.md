Pré-Requisitos
=================================================

# Plataforma

Todo o curso será executado na plataforma linux, com
sistema operacional Ubuntu 12 (Precise Pangolin).

Você pode executar o curso em Windows, já que todas as
ferramentas que precisamos estão disponíveis para ambos
sistemas operacionais.

---

# Software

Os softwares que serão usados durante o curso, com maior ou menor
extensão, são:

* PostgreSQL 9.1;
* PostGIS 2.0;
* pgAdmin3;
* git;
* QGis;

O PostgreSQL, PostGIS e o pgAdmin3 são auto-explicativos. Já o git será utilizado pelos alunos para realizar cópias dos exercícios e
para subir a resolução dos mesmos.

O Quantum GIS será utilizado na visualização de queries geoespaciais, utilizando o módulo RT Spatial Query.

---