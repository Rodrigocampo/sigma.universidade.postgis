Aula 03  = Funções Geoespaciais
=================================================

# Revisão aula 02

* Tipos geométricos;

* Sistemas de referência;

* Geometrias e Geografias;

* Funções de gerenciamento e funções de entrada;

---

# Nesta aula

* Validade de geometrias

* Relacionamentos Geoespaciais

* Matriz de intersecção DEI9M;

* Funções de relacionamentos geoespaciais;

---

# Validade

* Geometrias tem validade;

* Geometrias (e geografias) inválidas nos trazem resultados falsos;

* Somente temos polígonos válidos. Linhas sempre são válidas e pontos também;

* Polígonos precisam de estrutura;

---

# Quando um polígono é valido?

* Para um polígono ser válido, ele precisa:

	- O anel poligonal deve estar fechado (vértice inicial deve ser _exatamente_ igual ao vértice final);

	- Anéis internos que definem buracos devem estar dentro de anéis que definem as fronteiras externas;

	- Anéis não podem se interseccionar;

![Polígono inválido](img/aula03/invalido.png)

Fonte: [OpenGeo](http://workshops.opengeo.org/postgis-intro/validity.html)

* Aparentemente válido. Mas inválido! _Check it out!_;

```sql
SELECT ST_Area(ST_GeometryFromText('POLYGON((0 0, 0 1, 1 1, 2 1, 2 2, 1 2, 1 1, 1 0, 0 0))'));
```

* Uai! Como pode? Área zero?

* O algoritmo utilizado para cálculo de área faz uma conta em determinado sentido de vértices. Ele acaba calculando uma área como 1 e a outra como -1. A ordem dos vértices importa!

* Soma de trapézios para cálculo de área;

![Área de polígono](img/aula03/polyarea2.gif)

![Área de polígono](img/aula03/polyarea3.gif)

* Como o _software_ pode calcular a área de um polígono com buracos? E de um multi-polígono?

---

# Como verificar a validade de uma geometria?

* Temos a importantíssima função ST_IsValid(geometria);

```sql
SELECT ST_IsValid(ST_GeomFromText('POLYGON((0 0,1 1,1 0,0 1,0 0))'));
-- FALSE
```

## Inválida porque?

* ST_IsValidReason(geometria);

```sql
SELECT ST_IsValidReason(ST_GeomFromText('POLYGON((0 0,1 1,1 0,0 1,0 0))'));
-- "Self-intersection[0.5 0.5]"
```

## Resultados Bizarros

```sql
SELECT ST_Area(ST_GeomFromText('POLYGON((0 0,1 1,1 0,0 1,0 0))'));
-- 0?
```

---

# Como corrigir?

* A maior parte das vezes, polígonos são inválidos por conta de ```coisinhas```;

* faça um ST_Buffer de 0 ou de muito pouco e veja seu polígono ficar válido!

```sql
SELECT ST_IsValid(ST_Buffer(ST_GeomFromText('POLYGON((0 0,1 1,1 0,0 1,0 0))'),0));

-- TRUE
```

![ST_Buffer](img/aula03/st_buffer.png)

* Neste caso, quando o buffer foi executado, um vértice extra foi colocado no lugar correto, transformando esta geometria - clássico polígono banana;

* Imagine uma banana em que as pontas se tocam;

```sql
-- original
SELECT ST_IsValid(ST_GeomFromText('POLYGON((0 0, 2 0, 1 1, 2 2, 3 1, 2 0, 4 0, 4 4, 0 4, 0 0))'));

-- FALSE!

SELECT ST_IsValid(ST_Buffer(ST_GeomFromText('POLYGON((0 0, 2 0, 1 1, 2 2, 3 1, 2 0, 4 0, 4 4, 0 4, 0 0))'),0));

-- TRUE! mágica? Não!

SELECT ST_AsText(ST_IsValid(ST_Buffer(ST_GeomFromText('POLYGON((0 0, 2 0, 1 1, 2 2, 3 1, 2 0, 4 0, 4 4, 0 4, 0 0))'),0)));

-- "POLYGON((0 0,0 4,4 4,4 0,2 0,0 0),(2 0,3 1,2 2,1 1,2 0))"
```

* O PostGIS adicionou um buraco no polígono e tornou-o válido.

---

# Relacionamentos Geoespaciais

![Escher](img/aula03/escher.jpg)

---

# Matemática

* Relacionamentos geoespaciais são baseados em matemática;

* Teoria dos conjuntos;

* Trabalha com uma superfície de pontos infinitamente densa para modelar suas proposições;

---

# Conjunto de pontos

* Toda geometria é composta por um ponto ou um conjunto de pontos;

* Todas as operações levam em conta este conjunto, ```C```;

---

# Conjunto de pontos

* ```POLYGON((0 0,0 1,1 1,1 0,0 0))```

* C = { conjunto vértices + pontos entre vértices + interior };

---

# Bibliografia campeã

* [Geospatial Analysis - A comprehensive guide](http://www.spatialanalysisonline.com/)

* [GIS - A computing perspective](http://www.amazon.com/GIS-Computing-Perspective-Michael-Worboys/dp/0415283752)

---

# Polígonos

![Interior, Exterior e Limite - Polígono](img/aula03/de9im1.jpg)

Fonte: [OpenGeo](http://workshops.opengeo.org/postgis-intro/de9im.html)

---

# Linhas

![Interior, Exterior e Limite - Linha](img/aula03/de9im2.jpg)

Fonte: [OpenGeo](http://workshops.opengeo.org/postgis-intro/de9im.html)

---

# Pontos

* Caso especial

* Interior = próprio ponto;

* Exterior = todo o resto;

* Limite = conjunto vazio;

---

# DE-9IM

* Modelo topológico para descrever a relação entre duas geometrias;

* Desenvolvido por Clementini e Egenhofer;

* Oferece uma perspectiva para classificar relações espaciais;

* É uma matriz verdadeiro/falso;

* 512 possibilidades relacionais - agrupadas em 10 predicados;

---

# Modelo matricial

* Interior = I;

* Exterior = E;

* Limite = B;

* Pode ser representado por uma string de 9 caracteres, com os significados {T,F,*} (* = não me importo com o resultado);

* A matriz é composta pelo resultado dos testes entre as partes da geometria A e a geometria B;

![Matriz de intersecção](img/aula03/de9im3.jpg)

---

# Predicados geoespaciais

* Existem diversos tipos de predicados;

* Conceito de interior, exterior e limite;

* Todos os objetos possuem interior, exterior e limite;

* Os predicados são perguntas que te dizem se uma relação é verdadeira ou falsa;

---

# Predicados

* igual

* disjunto

* toca

* contém

* cobre

* cruza

* sobrepõe

* intersecciona

* está contido

* coberto por

---

# Igual

* Este predicado determina se as geometrias A e B são topologicamente iguais;

* Não quer dizer que as geometrias tenham os mesmos pontos!

* A e B são iguais sse seus interiores intersecionem e nenhuma parte do interior ou limite intersecione o exterior da outra;

* Representado pela string de teste DE9IM ```T*F**FFF*```;

* Comutativa (se A é igual a B, B é igual a A);

```sql
-- T
SELECT ST_Equals(ST_GeomFromText('LINESTRING(0 0, 10 10)'),
		ST_GeomFromText('LINESTRING(0 0, 5 5, 10 10)'));

-- T
SELECT ST_Equals(ST_Reverse(ST_GeomFromText('LINESTRING(0 0, 10 10)')),
		ST_GeomFromText('LINESTRING(0 0, 5 5, 10 10)'));
```

* Para verificar que uma geometria é __EXATAMENTE__ igual a outra, use a função ST_OrderingEquals;

---

# Disjunto

* Este predicado determina se as geometria A e B são topologicamente distintas e não se tocam de maneira alguma, ou seja, são desconectadas espacialmente;

* String DE9IM ```FF*FF****```;

* Mesmo que _NÃO INTERSECCIONA_;

* Comutativo (se A é disjunto de B, B também é disjunto de A);

```sql
-- TRUE
SELECT ST_Disjoint('POINT(0 0)'::geometry, 'LINESTRING ( 2 0, 0 2 )'::geometry);

-- FALSE
SELECT ST_Disjoint('POINT(0 0)'::geometry, 'LINESTRING ( 0 0, 0 2 )'::geometry);

```

## Ou então...

* Intersects ao contrário é a mesma coisa que disjunto;

```sql
-- TRUE
SELECT NOT ST_Intersects('POINT(0 0)'::geometry, 'LINESTRING ( 2 0, 0 2 )'::geometry);


-- FALSE
SELECT NOT ST_Intersects('POINT(0 0)'::geometry, 'LINESTRING ( 0 0, 0 2 )'::geometry);
```

---

# Toca

* A toca B;

* Testa que A tem pelo menos um ponto em seu limite que é comum com o limite de B, mas sem pontos interiores em comum (se existem pontos interiores em comum, o resultado é falso.);

```sql
-- Toca!
SELECT ST_Touches(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((1 1,1 2,2 2,2 1,1 1))'));

-- não toca, pois os interiores tem pontos em comum
SELECT ST_Touches(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((.5 .5,.5 1.5,1.5 1.5,1.5 0.5,0.5 0.5))'));
```

* String DE9IM ```FT*******```, ```F**T*****``` e ```F***T****```;

---

# Contém

* A contém B sse nenhum ponto de B está no exterior de A e pelo menos um ponto de B está no interior de A;

* String DEI9M ```T*****FF*```,```*T****FF*```,```***T**FF*```,```****T*FF*```;

* A contém seu interior, mas não seu limite;

* ST_Contains;

* ST_Contains(A,B) = ST_Within(B,A);

```sql
SELECT ST_Contains(
	ST_GeomFromText('POLYGON((0 0,0 10,10 10,10 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'));

-- TRUE

SELECT ST_Contains(
	ST_GeomFromText('POLYGON((0 0,0 10,10 10,10 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 10,10 10,10 0,0 0))'));

-- A contém A'
-- TRUE 

SELECT ST_Contains(
	ST_GeomFromText('POLYGON((0 0,0 10,10 10,10 0,0 0))'),
	ST_Boundary(ST_GeomFromText('POLYGON((0 0,0 10,10 10,10 0,0 0))')));

-- A __NÃO__ contém o limite de A!!!;
-- FALSE
```

---

# Cobre

* A cobre B;

* Geometria B está no interior de A;

* Nenhum ponto de B está no exterior de A;

* DE9IM ```T*****FF**```,```*T****FF*```, ```***T*FF*```, ```****T*FF*```;

```sql
SELECT ST_Covers(
	ST_GeomFromText('POLYGON((0 0,0 10,10 10,10 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 10,10 10,10 0,0 0))'));

-- TRUE, nenhum ponto de B está no exterior de A;

SELECT ST_Covers(
	ST_GeomFromText('POLYGON((0 0,0 10,10 10,10 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 12,12 12,12 0,0 0))'));

-- FALSE, alguns pontos de B estão no exterior de A;
```

---

# Cruza

* A cruza B;

* A cruza B sse alguns, mas não todos pontos do interior de A são comuns a B;

* A dimensionalidade do resultado é a menor das duas geometrias (poligono x linha = linha);

* Funciona com ponto x linha, ponto x área ,linha x área e linha x linha;

* Qualquer outra combinação de tipos geométricos é Falso;

* DE9IM ```T*T******```,```T*****T**```, ```0********```;

```sql

SELECT ST_Crosses(
	ST_GeomFromText('LINESTRING(0 0,10 10)'),
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'));

-- TRUE

SELECT ST_Crosses(
	ST_GeomFromText('LINESTRING(0 0,10 10)'),
	ST_GeomFromText('LINESTRING(0 10,10 0)'));

-- TRUE, as linhas se cruzam

SELECT ST_Crosses(
	ST_GeomFromText('LINESTRING(0 0,10 10)'),
	ST_GeomFromText('LINESTRING(10 10,20 20)'));

-- FALSE, as linhas não se cruzam

SELECT ST_Crosses(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'));
-- FALSE, polígono não cruza polígono.

```

---

# Sobrepõe

* A sobrepõe B;

* A sobrepõe B sse A e B tenham alguns, mas não todos os pontos em comum, eles possuem a mesma dimensionalidade e a a intersecção do interior das duas geometrias possuem a mesma dimensionalidade que as geometrias;

* Elas se intersecionam, mas nenhuma contém a outra;

* DE9IM ```T*T***T**```,```1*T***T**```;

```sql

SELECT ST_Overlaps(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'));

SELECT ST_Overlaps(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((0.5 0.5,0.5 1,1 1,1 0.5,0.5 0.5))'));

-- FALSE, elas se sobrepõe, mas uma geometria contém a outra.
```

---

# Interseciona

* A interseciona B;

* A interseciona B sempre que a e b tiverem pelo menos um ponto em comum;

* Comutativa (se A interseciona B, B interseciona A);

* DE9IM ```T********```, ```*T*******```, ```***T*****```,```****T****```;

* Este predicado leva em conta o interior e o limite. Se duas geometrias dividem um ponto em seu limite, elas se intersecionam;

```sql
SELECT ST_Intersects(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'));

-- TRUE

SELECT ST_Intersects(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((1 1,1 2,2 2,2 1,1 1))'));

-- TRUE, dividem apenas um ponto;
```

* O inverso da função ST_Intersects é a função NOT ST_Disjoint;

---

# Está contido

* A está contido em B;

* A está contido em B apenas quando a está no interior de B;

* DE9IM ```T*F**F***```;

```sql

SELECT ST_Within(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((.5 .5,.5 .6,.5 .5,.6 .5,.5 .5))'));

-- False (o quadrado maior não está dentro do menor)

SELECT ST_Within(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 6,6 6,6 0,0 0))'));

-- TRUE, o quadrado menor está dentro do maior;
```

---

# Coberto por

* A está coberto por B;

* Todos os pontos de B são pontos de A e os interiores das duas geometrias tem pelo menos um ponto em comum;

* Verdadeiro se nenhum ponto da geometria A está no exterior de B;

* DE9IM ```T*F**F***```,```*TF**F***```,```**FT*F***```,```**F*TF***```;

```sql
SELECT ST_CoveredBy(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((0 0,0 6,6 6,6 0,0 0))'));

-- TRUE
```

---

# Agrupando informações

* As vezes é necessário agrupar informações. Unir pedaços;

* Construção de geometrias complexas via queries, sem a necessidade de armazená-las;

* Temos algumas maneiras de fazer isto:

* ```ST_Union``` e ```ST_Collect```;

---

# ST_Union

* Versão de agregação (temos que usar com ```GROUP BY```);

```sql
SELECT "NAME_2",ST_Union(the_geom),ST_Area(ST_Union(the_geom)),ST_Perimeter(ST_Union(the_geom)) FROM distrito WHERE "NAME_2" LIKE 'Uberlâ%' GROUP BY "NAME_2"
-- resultado editado...
-- "Uberlândia";"POLYGON((-48.8216323849999 -19.102262497,-48.8048286439999 -19.0888004299999,-48.780471802 -19.0847549439999,-48.7612190249999 -19.0762710569999,-48.752243042 -19.0796794889999,-48.7491760249999 -19.0755157469999,-48.744213104 -19.0792942049999,-48.737056732 -19.07393837,-48.7232704159999 -19.075597763,-48.7222213749999 -19.070590973,-48.7062606809999 -19.0746936799999,-48.6912384029999 ...))";0.353381284455054;4.26091264581061
```

* Versão simples (chamada entre duas geometrias);

```sql
-- retorno simples, apenas um polígono
SELECT ST_AsText(ST_Union(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((.5 .5,.5 1.5,1.5 1.5,1.5 .5,.5 .5))')))
-- "POLYGON((0 0,0 1,0.5 1,0.5 1.5,1.5 1.5,1.5 0.5,1 0.5,1 0,0 0))"

-- retorno complexo, multi poligonal
SELECT ST_AsText(ST_Union(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((1 1,1 2,2 2,2 0,1 1))')))
-- "MULTIPOLYGON(((0 0,0 1,1 1,1 0,0 0)),((1 1,1 2,2 2,2 0,1 1)))"
```` 

* Esta funcionalidade dissolve os limites entre as geometrias de entrada, na tentativa de garantir que a geometria seja válida.

---

# ST_Collect

* Versão de agregação (temos que usar com ```GROUP BY```);

```sql
SELECT "NAME_2",ST_AsText(ST_Collect(the_geom)),ST_Area(ST_Collect(the_geom)),ST_Perimeter(ST_Collect(the_geom)) FROM distrito WHERE "NAME_2" LIKE 'Uberlâ%' GROUP BY "NAME_2"
-- "Uberlândia";"MULTIPOLYGON(((-48.8216323849999 -19.102262497,-48.8048286439999 -19.0888004299999,-48.780471802 -19.0847549439999,-48.7612190249999 -19.0762710569999,-48.752243042 -19.0796794889999,-48.7491760249999 -19.0755157469999,-48.744213104 -19.0792942049999,-48.737056732 -19.07393837,-48.7232704159999 -19.075597763,-48.7222213749999 -19.070590973,-48.7062606809999 -19.0746936799999,-48.6912384029999 -19.04265213,-48.677768707 -19.032142639,-48.675052643 -19.0184135439999,-48.6583824159999 -19.009538651,-48.6543083189999 -19.001390457,-48.645420074 -18.9972763059999,-48.6427040099999 -18.9848651889999,-48.64484787 -18.9753303529999,-48.633087158 -18.954662323,-48.624713898 -18.9564533229999, ...)))";0.353381284455054;7.29538486885236
```

* Versão simples (chamada entre duas geometrias);

```sql
SELECT ST_AsText(ST_Collect(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((.5 .5,.5 1.5,1.5 1.5,1.5 .5,.5 .5))')))
-- "MULTIPOLYGON(((0 0,0 1,1 1,1 0,0 0)),((0.5 0.5,0.5 1.5,1.5 1.5,1.5 0.5,0.5 0.5)))"

SELECT ST_AsText(ST_Collect(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('POLYGON((1 1,1 2,2 2,2 0,1 1))')))
-- "MULTIPOLYGON(((0 0,0 1,1 1,1 0,0 0)),((1 1,1 2,2 2,2 0,1 1)))"
```

* ```ST_Collect``` é bem mais rápido que ```ST_Union```;

* ```ST_Collect``` **não** dissolve os limites entre polígonos ou linhas;

---

# Funções de Propriedades Geométricas

* ST_GeometryType - retorna o tipo da geometria;

```sql
SELECT ST_GeometryType(ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'));
-- ST_Polygon;
```
	
* ST_Envelope - retorna o polígono composto pela BOX2D da geometria;

```sql
SELECT ST_AsText(ST_Envelope(ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))')));
-- "POLYGON((0 0,0 1,1 1,1 0,0 0))"
```
	
* ST_Boundary - retorna o limite da geometria (lembrem-se do que discutimos nos relacionamentos);

```sql
SELECT ST_AsText(ST_Boundary(ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))')));
-- "LINESTRING(0 0,0 1,1 1,1 0,0 0)"
```
	
* ST_IsValid - retorna se a geometria é válida;

```sql
SELECT ST_IsValid(ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'));
-- TRUE
```
	
* ST_IsValidReason - retorna o motivo pelo qual a geometria é considerada inválida;

```sql
SELECT ST_IsValidReason(ST_GeomFromText('POLYGON((0 0,1 1,1 0,0 1,0 0))'));
-- "Self-intersection[0.5 0.5]"
```
	
* ST_IsValidDetail - retorna se  a geometria é válida e o porque ela é inválida;

* ST_NPoints - retorna o número de pontos em uma geometria;

```sql
SELECT ST_NPoints(ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'));
-- 5
```

* ST_PointN - retorna o ponto de índice n (índices iniciam em 1 _não_ em 0). Retorna NULO para geometrias que não são lineares (diferentes de LINESTRING ou CIRCULARLINESTRING);

```sql
SELECT ST_AsText(ST_PointN(ST_GeomFromText('LINESTRING(0 0,1 1,1 0,0 1,0 0)'),1));
-- "POINT(0 0)"
```

* ST_StartPoint - retorna o primeiro ponto de uma linha - retorna nulo para uma geometria que não seja linear;

```sql
SELECT ST_AsText(ST_StartPoint(ST_GeomFromText('LINESTRING(0 0,1 1,1 0,0 1,0 0)')));
-- "POINT(0 0)"
```

* ST_EndPoint - retorna o último ponto de uma linha - retorna nulo para uma geometria que não seja linear;

```sql
SELECT ST_AsText(ST_EndPoint(ST_GeomFromText('LINESTRING(0 0,1 1,1 0,0 1,10 10)')));
-- "POINT(10 10)"
```

* ST_SRID - retorna o SRID da geometria em questão;

```sql
SELECT ST_SRID(ST_EndPoint(ST_GeomFromText('LINESTRING(0 0,1 1,1 0,0 1,10 10)')));
-- -1

SELECT ST_SRID(ST_EndPoint(ST_GeomFromText('LINESTRING(0 0,1 1,1 0,0 1,10 10)',4674)));
-- 4674
```

* ST_X - retorna a ordenada X de um ponto;
* ST_Y - retorna a ordenada Y de um ponto;
* ST_Z - retorna a ordenada Z de um ponto;
* ST_M - retorna a ordenada M de um ponto;

```sql
-- x y
SELECT
	ST_X(pt.ponto),ST_Y(pt.ponto),ST_Z(pt.ponto),ST_M(pt.ponto) FROM (SELECT ST_MakePoint(10,11) as "ponto") pt
-- 10;11;

-- x y z
SELECT
	ST_X(pt.ponto),ST_Y(pt.ponto),ST_Z(pt.ponto),ST_M(pt.ponto) FROM (SELECT ST_MakePoint(10,11,12) as "ponto") pt
-- 10;11;12;

-- x y z m
SELECT
	ST_X(pt.ponto),ST_Y(pt.ponto),ST_Z(pt.ponto),ST_M(pt.ponto) FROM (SELECT ST_MakePoint(10,11,12,13) as "ponto") pt
-- 10;11;12;13;
```

---

# Funções de Edição

* ST_AddPoint - adicionar um ponto na linha desejada

```sql
SELECT ST_AsText(ST_AddPoint(ST_GeomFromText('LINESTRING(0 0,1 1)'),ST_MakePoint(2,2)));
-- "LINESTRING(0 0,1 1,2 2)"

SELECT ST_AsText(ST_AddPoint(ST_GeomFromText('LINESTRING(0 0,1 1)'),ST_MakePoint(2,2),0));
-- "LINESTRING(2 2,0 0,1 1)"
```

* ST_LineMerge - retorna uma linha de uma multilinha, desde que elas se toquem;

```sql
SELECT ST_AsText(ST_LineMerge(
ST_GeomFromText('MULTILINESTRING((-29 -27,-30 -29.7,-36 -31,-45 -33),(-45 -33,-46 -32))')));
-- LINESTRING(-29 -27,-30 -29.7,-36 -31,-45 -33,-46 -32)
```

* ST_Multi - transforma a geometria em uma multi-geometria. Útil para alimentar funções plpgsql;

```sql
SELECT ST_GeometryType(ST_Multi(ST_MakePoint(0,0)));

-- ST_MultiPoint
```

* ST_SetSRID - seta o SRID de uma geometria

```sql
SELECT ST_SRID(ST_SetSRID(ST_GeomFromText('POINT(0 0)'),4674));
```

* ST_Transform - transforma o sistema de referência da coordenada;

```sql
SELECT ST_AsText(ST_Transform(ST_GeomFromText('POINT(-42 -19)',4674),31969));
-- "POINT(6498262.81808638 -3179428.23556384)"
```

* ST_Translate - move a geometria por um determinado valor de x y;

```sql
SELECT ST_AsText(ST_Translate(ST_GeomFromText('POINT(0 0)'),10,10);
-- "POINT(10 10)"
)
```

---

# Funções de Saída

* Funções importantes para determinar ou "cuspir" geometrias em outros formatos;

* ST_AsEWKB - retorna a geometria em formato binário extendido;

* ST_AsWKB - retorna a geometria em formato binário OGC;

* ST_AsText - retorna a geometria em formato texto OGC (apelido para ST_AsWKT);

* ST_GeoHash - retorna a codificação geohash de uma geometria pontual em lat/long. Não funciona em outras SRIDs que não sejam geográficos;

```sql
SELECT ST_GeoHash(ST_GeomFromText('POINT(-19.53 -34.21)'));
-- "79fj7s68q1b907sr1pwu"
```

# Funções de Medição

* ST_Distance - mede a menor distância entre duas geometrias;

```sql
SELECT ST_Distance(ST_MakePoint(0,0),ST_MakePoint(1,1));
-- 1.4142135623731
```

* ST_MaxDistance - retorna a distância máxima entre duas linhas;

* existem algumas dúvidas sobre esta função que já foram propagadas para os meios 'corretos'. Para mim a distância máxima entre estas duas linhas é 2;

```sql
SELECT ST_MaxDistance(
	ST_MakeLine(ST_MakePoint(0,0),ST_MakePoint(1,1)),
	ST_MakeLine(ST_MakePoint(0,0),ST_MakePoint(-1,1)));
-- 2.0
```

* ST_Area - retorna a área de um polígono;

* ST_Perimeter - retorna o perímetro de um polígono;

* ST_Length , ST_Length2D,ST_3DLength - retorna o comprimento de uma linha, em 2d e 3d;

* ST_Centroid - retorna o centróide de uma geometria;

* para multipontos o centróide é uma média aritmética;

* para as outras geometrias o centróide é uma média ponderada;

```sql
SELECT ST_AsText(ST_Centroid(ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))')));
-- "POINT(0.5 0.5)"
```

* ST_Azimuth - calcula o ângulo entre dois pontos e o plano normal (em radianos);

```sql
SELECT degrees(ST_Azimuth(ST_MakePoint(0,0),ST_MakePoint(1,1)));
-- 45

SELECT ST_Azimuth(ST_MakePoint(0,0),ST_MakePoint(0,1));
-- 0

SELECT degrees(ST_Azimuth(ST_MakePoint(1,0),ST_MakePoint(0,0)));
-- 270
```

---

# Funções de Processamento

* ST_Intersection - retorna a intersecção entre duas geometrias
* ST_Buffer;
* ST_Collect;
* ST_Split;
* ST_Union;

---

# ST_Intersection

* Retorna a intersecçõ entre duas geometrias.

* Vimos funções que detectam intersecções entre geometrias. Esta função retorna os pontos em comum entre A e B;

```sql
SELECT ST_AsText(ST_Intersection(
	ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))'),
	ST_GeomFromText('LINESTRING(-1 -1,.5 .5)')));
-- "LINESTRING(0 0,0.5 0.5)"
```

---

# ST_Buffer

* Expande a todos os vértices da geometria em x unidades (em unidades do SRID);

```sql
SELECT ST_AsText(ST_Buffer(ST_GeomFromText('POINT(0 0)'),1));

--- "POLYGON((1 0,0.980785280403231 -0.195090322016128,0.923879532511287 -0.382683432365089,0.831469612302546 -0.555570233019602,0.707106781186548 -0.707106781186547,0.555570233019603 -0.831469612302545,0.382683432365091 -0.923879532511286,0.19509032201613 -0.98078528040323,1.61554255216634e-015 -1,-0.195090322016126 -0.980785280403231,-0.382683432365088 -0.923879532511288,-0.555570233019601 -0.831469612302546,-0.707106781186546 -0.707106781186549,-0.831469612302544 -0.555570233019604,-0.923879532511286 -0.382683432365092,-0.98078528040323 -0.195090322016131,-1 -3.23108510433268e-015,-0.980785280403231 0.195090322016125,-0.923879532511288 0.382683432365086,-0.831469612302547 0.555570233019599,-0.70710678118655 0.707106781186545,-0.555570233019606 0.831469612302543,-0.382683432365094 0.923879532511285,-0.195090322016132 0.98078528040323,-3.73640463187386e-015 1,0.195090322016125 0.980785280403231,0.382683432365087 0.923879532511288,0.5555702330196 0.831469612302547,0.707106781186545 0.70710678118655,0.831469612302544 0.555570233019604,0.923879532511286 0.382683432365092,0.98078528040323 0.19509032201613,1 0))"

SELECT ST_Area(ST_Buffer(ST_GeomFromText('POINT(0 0)'),1));
-- 3.12144515225805
```

---

# Exercícios para a semana

* [[Exercícios Aula 03|exercicios_aula03]]