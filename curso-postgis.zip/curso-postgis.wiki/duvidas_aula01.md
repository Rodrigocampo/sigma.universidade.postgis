# Dúvidas Aula 01

## Se eu inserir diretamente no banco dá certo, como fizemos na aula.
mas pela aplicação não.
Alguém consegue vê algum problema na query ai??

String sql = "INSERT INTO teste(geometria) values (?)";
        PreparedStatement ps;
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, "ST_GeomFromText(" + acidente.getLocalizacao() + ",4618)");
        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }


E ainda ela não lança nenhuma exceção nem dá problema nenhum, e o principal, não insere no banco..
Alguem visualiza problema?

### O problema estava na forma como a aplicação estava amarrando o parâmetro (texto) com o resultado da função.

Quando substituído, o resultado era o seguinte:

```"INSERT INTO teste(geometria) values ('ST_GeomFromText(x y)')";```

Note que a aplicação estava quotando de forma errônea a função ST_GeomFromText.