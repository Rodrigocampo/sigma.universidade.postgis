Cronograma
=================================================

Nossas aulas tem início no dia 15/09 e os horários programados
são sempre de 09:00 - 12:00 e 13:00 - 18:00;

* Aula 01 - 15/09/2012

* Aula 02 - 22/09/2012

* Aula 03 - 29/09/2012

* Aula 04 - 06/10/2012

