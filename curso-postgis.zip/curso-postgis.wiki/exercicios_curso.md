# Exercícios Curso

Esta é a lista de exercícios do curso de PostGIS. Nesta lista teremos um agregado de questões, passando por todas as aulas, de diversos tipos.

# Dados utilizados

Os dados utilizados estão disponíveis publicamente e estão no repositório:

* Shapefile de hidrografia (ANA);
* Shapefile de municípios (IBGE);
* Shapefile de estados (IBGE);

## Banco de dados

### Criando um banco de dados geoespacial

1. Crie um banco de dados comum, sem derivar do template criado pelo PostGIS. Adicione o suporte geoespacial do PostGIS posteriormente. Quais são as etapas? Detalhe ou escreva um script shell (bash ou bat);

### Criando um banco de dados template

1. Crie um banco para servir de template para o PostGIS. Quais são as dificuldades? Quais são as coisas que podemos fazer para facilitar a administração de *setups* complexos de bancos de dados?

## Arquitetura PostGIS

1. Quais são as tabelas especiais que o PostGIS utiliza para funcionar? Liste-as e explique a função de cada uma.

2. Até na versão 1.5 a tabela *geometry_columns* era uma tabela física. Na versão 2.0 ela não é mais uma tabela. O que ela é?

3. Quais são os motivos pelos quais o PostGIS armazena estas meta-tabelas.

4. Quais são as bibliotecas que suportam o PostGIS? Porque elas estão sendo utilizadas?

## Carga

1. Faça a carga dos dados disponíveis no repositório em um novo banco de dados. Utilize os nomes **hidrografia**,**municipio** e **estado**. Carregue os dados no *schema* **public** (existe um bug associado a exportação de dados em outros schemas). Detalhe os passos utilizados para tal.
2. Exporte os dados carregados para shapefile. Detalhe os passos utilizados para tal.

## Construção de tabelas

1. Construa uma tabela que represente um foco de dengue. Qual é o SQL correspodente? Justifique o tipo do dado geoespacial utilizado.

2. Construa uma tabela que represente um logradouro. Podemos utilizar mais de um tipo geométrico para esta tabela? Qual é a vantagem ou desvantagem de cada tipo? Qual é o SQL correspodente e justifique a escolha do tipo geométrico.

3. Construa uma tabela que represente trechos de viagens aéreas. Qual é o tipo geométrico associado? Justifique sua escolha.

4. Construa uma tabela que represente lotes urbanos. Qual é o tipo geométrico associado e justifique.

5. Quais são as restrições padrão criadas pelo PostGIS quando se utiliza a função *AddGeometryColumn**? Qual é a função de cada uma?

6. Existem situações onde as restrições padrões não são interessantes?

7. Quais funções podemos utilizar para mudar a restrição de SRID, **sem dropar a coluna geométrica**?

8. 

## SRID

1. O que é um SRID?
2. Como posso transformar de um SRID para outro?
3. Qual é a soma do comprimento de todos os cursos d´água? Dica: ST_Length. O valor retornado está em qual unidade?
4. Qual é a soma do comprimento de todos os cursos d´água que intersecionam a cidade de Uberlândia-MG em metros.
5. Quando desejamos trabalhar com uma projeção customizada, devemos inserir dados sobre esta projeção no PostGIS. Qual tabela utilizamos para tal?
6. Qual é a área em hectares de 100 metros de APP do rio Uberabinha (dica: ```select * from hidrografia where "NORIO" = 'Uberabinha'```);
7. Um sistema de coordenada projetado depende de quais informações para localizar corretamente um ponto na superfície da Terra?
8. 

## Modelo de dados

* Crie, com uma ou mais tabelas, uma representação de vias de logradouro, onde as seguintes premissas são verdadeiras:

1. O conceito de um trecho de logradouro é uma parte de um logradouro, determinado pela intersecção entre outros dois logradouros;
	
2. As informações podem variar de acordo com o trecho;
	
3. É necessário agrupar as informações de trechos de logradouro de acordo com o seu logradouro;

4. Trechos possuem os seguintes atributos: ```índice (posição do trecho no conjunto de logradouro), numeração inicial esqueda, numeração inicial direita, numeração final esquerda, numeração final direita, sentido () id do logradouro``` e os logradouros possuem os seguintes atributos: ```id logradouro, tipo do logradouro, nome do logradouro```

5. Crie uma view que agregue os dados dos trechos logradouros, na ordem correta e represente uma geometria do logradouro completo. Dica: ```ORDER BY``` e ```ST_Collect``` são seus amigos.

## Geometrias

1. Construa em WKT uma geometria de cada tipo (```POINT, LINESTRING, POLYGON, MULTIPOINT, MULTILINESTRING e MULTIPOLYGON`` `). Utilize a função ```ST_GeomFromText``` para a construção das geometrias.

2. Como podemos detectar uma geometria inválida? 

3. O polígono ```POLYGON((0 0, 0 1, 1 1, 2 1, 2 2, 1 2, 1 1, 1 0, 0 0))``` é válido? Se não, qual é o motivo de o mesmo ser inválido?

4. Polígonos são o único tipo de geometria que possuem validade? Quais são os problemas decorrentes de geometrias inválidas?

5. Corrija a invalidez da seguinte geometria: ```POLYGON((0 0, 2 0, 1 1, 2 2, 3 1, 2 0, 4 0, 4 4, 0 4, 0 0))```.

6. Execute o seguinte comando SQL e determine:
	6.1 Os polígonos que são exatamente iguais ```ST_OrderingEquals```;
	6.2 Os polígonos que são espacialmente iguais ```ST_Equals```;
	6.3 Os polígonos que tem o retângulo envolvente igual;
	6.4 Quais são as diferenças entre cada método? Qual é o método mais eficiente e menos eficiente?

	```sql
	CREATE TABLE polygons (id integer, name varchar, poly geometry);

	INSERT INTO polygons VALUES
	  (1, 'Polygon 1', 'POLYGON((-1 1.732,1 1.732,2 0,1 -1.732,
	      -1 -1.732,-2 0,-1 1.732))'),
	  (2, 'Polygon 2', 'POLYGON((-1 1.732,-2 0,-1 -1.732,1 -1.732,
	      2 0,1 1.732,-1 1.732))'),
	  (3, 'Polygon 3', 'POLYGON((1 -1.732,2 0,1 1.732,-1 1.732,
	      -2 0,-1 -1.732,1 -1.732))'),
	  (4, 'Polygon 4', 'POLYGON((-1 1.732,0 1.732, 1 1.732,1.5 0.866,
	      2 0,1.5 -0.866,1 -1.732,0 -1.732,-1 -1.732,-1.5 -0.866,
	      -2 0,-1.5 0.866,-1 1.732))'),
	  (5, 'Polygon 5', 'POLYGON((-2 -1.732,2 -1.732,2 1.732,
	      -2 1.732,-2 -1.732))');

	 SELECT Populate_Geometry_Columns();
	 ```

7. Obtenha o retângulo envolvente em duas dimensões da geometria ```POLYGON((0 0,0 1,1 1,1 0,0 0))```.

8. Para que servem os retângulos envolventes? Qual é o seu papel na otimização do funcionamento do PostGIS e outros GIS em geral?

9. Obtenha o centróide do estado de Minas Gerais;

10. Obtenha a expansão de 100 metros do estado de Minas Gerais;

11. Obtenha a intersecção entre o estado de Minas Gerais e toda a rede hidrográfica do estado. Qual é seu comprimento em metros?

12. Obtenha o limite do Brasil através da união de todos os estados (dica: ST_Union);

13. 