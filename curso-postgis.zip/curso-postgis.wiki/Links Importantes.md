Links Importantes
=================================================

Nesta seção listaremos links importantes, tanto como
referência como recursos, instaladores, etc.

# Instaladores

## PostgreSQL
-------------------------------------------------

* [[Site Oficial PostgreSQL|www.postgresql.org]]
* [[PostgreSQL Extension Network]]

## PostGIS
-------------------------------------------------

* [[Site Oficial PostGIS|www.postgis.org]]

## GEOS
-------------------------------------------------

* [[Site Oficial GEOS|www.geos.org]]

## Proj4
-------------------------------------------------

* [[Site Oficial Proj4|www.proj4.org]]

# Recursos diversos

## Spatial References.org

* [[Site Spatial References|www.spatialreferences.org]]

Site fantástico com registro de (quase) todos os sistemas de referência utilizados mundo afora.