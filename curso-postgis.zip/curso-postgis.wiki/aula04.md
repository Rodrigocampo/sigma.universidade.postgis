Aula 04 - Experiência de Mundo Real
=================================================

# Experiência de Mundo Real

# Geoespacial é Especial?

* Existe muita discussão sobre o quão especial (ou não) a tecnologia GIS é);

* O que vocês acham?

* Silos de informação;

* Dificuldade de integrar sistemas;		

# plpgsql pesado;

* use testes unitários;

* use um debugger;		

# Testes unitários

* Testes unitários lhe darão tranquilidade para dormir;

* Código escrito é código testado;

* Sem surpresas. A suíte de teste é um X9. O que passou, passou.

* Existe recursos muito bons na web sobre testes. Mas e sobre testes de funções no banco de dados?

---

# Testes unitários com pgTAP

* o desenvolvimento em pl/pgsql é difícil;

* estrutura de apoio é complexa;

* precisamos de mais ferramentas

---

# pgTAP - framework de testes unitários

* instalação simples em ambiente linux (```CREATE EXTENSION```);

```bash
# script de instalação do pgTAP
# download e descompactação
sudo wget http://pgfoundry.org/frs/download.php/3183/pgtap-0.90.0.tar.bz2
sudo tar -xvf pgtap-0.90.0.tar.bz2

# instalaçaõ
cd pgtap-0.90.0/
sudo make
sudo make install

cd ..
rm -rf pgtap-0.90.0/
rm -rf pgtap-0.90.0.tar.bz2

# todo: finalizar
su - postgres

psql -c "CREATE EXTENSION pgtap";
# carga
psql -d template1 -f /usr/share/postgresql/9.1/contrib/pgtap/pgtap.sql
psql -d template_postgis -f /usr/share/postgresql/9.1/contrib/pgtap/pgtap.sql
```

* nos permite testar código pl/pgsql e obter um caminhão de documentação sobre como o código funciona;

* API fácil;

---

# pgTAP - exemplos

* Dada uma função que tem como objetivo mover objetos alguns metros para esquerda ou direita, para cima ou para baixo:

```sql
CREATE OR REPLACE FUNCTION (p_geom geometry,dx double precision,dy double precision) 
RETURNS GEOMETRY AS
$$
DECLARE

	v_result GEOMETRY;

BEGIN

	-- eu sei, não é uma implementação de verdade...
	v_result := ST_Translate(p_geom,dx,dy);

END;
$$
LANGUAGE plpgsql;
```

* Lembre-se: a implementação, por agora não é importante. Iremos finalizá-la depois.

* Esta função moveria toda uma geometria para através dos deltas igualmente, a partir do ponto inicial, portanto o teste da mesma está a sguir, seguindo o modelo AAA (*arrange,act,assert* - ajustar, agir e confirmar);

```sql
CREATE OR REPLACE FUNCTION test_move_geometry () RETURNS SETOF TEXT AS
$$
DECLARE

	original_geom_a GEOMETRY;
	actual_geom_a GEOMETRY;
	expected_geom_a GEOMETRY;

	original_geom_b GEOMETRY;
	actual_geom_b GEOMETRY;
	expected_geom_b GEOMETRY;

	original_geom_c GEOMETRY;
	actual_geom_c GEOMETRY;
	expected_geom_c GEOMETRY;

BEGIN

	-- arrange
	original_geom_a := ST_GeomFromText('POINT(0 0)');
	original_geom_b := ST_GeomFromText('LINESTRING(0 0,1 1)');
	original_geom_c := ST_GeomFromText('POLYGON((0 0,0 1,1 1,1 0,0 0))');

	expected_geom_a := ST_GeomFromText('POINT(-1 -1)');
	expected_geom_b := ST_GeomFromText('LINESTRING(-1 -1,0 0)');
	expected_geom_c := ST_GeomFromText('POLYGON((-1 -1,-1 0,0 0,0 -1,-1 -1))');

	-- act
	actual_geom_a := move_geometry(original_geom_a,-1,-1);
	actual_geom_b := move_geometry(original_geom_b,-1,-1);
	actual_geom_c := move_geometry(original_geom_c,-1,-1);

	-- assert
	RETURN NEXT ok(ST_OrderingEquals(expected_geom_a,actual_geom_a),'Teste de mover geometria para ponto.');

	RETURN NEXT ok(ST_OrderingEquals(expected_geom_b,actual_geom_b),'Teste de mover geometria para linha.');

	RETURN NEXT ok(ST_OrderingEquals(expected_geom_c,actual_geom_c),'Teste de mover geometria para polígono.');

END;
$$
LANGUAGE plpgsql;
```

* Rode os testes:

```sql

SELECT * from runtests();

-- ok Teste de mover geometria para ponto.
-- ok Teste de mover geometria para linha.
-- ok Teste de mover geometria para polígono.
```

* Cada RETURN NEXT alimenta o número de caso de testes. A função ```ok``` é o que determinará falha/sucesso do teste.

* Apesar de nossa implementação apenas consumir uma função já muito bem testada da suíte do PostGIS, este **exemplo** serve para ilustrar o funcionamento do pgTAP.

* O pgTAP tem uma API bacana. Você pode testar se diversos objetos de schema existem facilmente, se valores batem, se não batem, se são nulos, e aí por diante.

---

# Debugger

* existe o debugger do pgAdmin: http://www.pgadmin.org/docs/1.8/debugger.html;

* padrão;

* fácil de instalar;

---

# Window functions ao resgate!

* Window functions são funções que realizam algum cálculo sobre um conjunto de linhas, relacionadas com a linha da query atual;

* Podemos olhar para a linha anterior, para a linha posterior e inclusive agregar dados;

* Façam download do arquivo ```gps.sql``` em downloads.

* Vamos descobrir as linhas relacionadas a cada ponto gps e o ponto anterior;

* Vantagens: imaginem se fossemos criar uma função *plpgpsql* que buscasse a linha anterior e a linha posterior?! Três vezes o número de consultas!

---

# Função Window

* O objetivo é criar uma query que me calcule a linha do ponto atual até o ponto anterior de gps, baseado no timestamp;

````sql
SELECT 
	id,
	machine,
	geom as "atual",
	lag(geom) OVER w as "ponto_anterior" ,
	ST_MakeLine(lag(geom) OVER w,geom)  
FROM sentence_gps
WINDOW w AS (PARTITION BY machine ORDER BY "timestamp")
LIMIT 100
```

* Lembre-se de usar LIMIT nestas queries (o dump é grandinho);

* As funções window são capetinhas. Com elas conseguimos fazer análises de dados GIS e temporais de forma rápida e simples.

* Assim como lag, que acessa a linha anterior da query, temos lead (linhas posteriores) e em ambos os casos podemos utilizar a função com mais um parâmetro, para indicar qual é o próximo (segundo, terceiro, quarto, n);

---

# Geometrias calculadas

* com as window functions tivemos um exemplo legal de como calcular geometrias dinamicamente;

* Temos várias utilidades para isto, como criar views que reflitam o estado atual de dados difíceis de se controlar
manualmente ou com *triggers*;

* Imagine as seguintes tabelas

```sql
CREATE TABLE ponto (
	nome VARCHAR(5) PRIMARY KEY);

SELECT * FROM AddGeometryColumn('public','ponto','geom',-1,'POINT',2);

CREATE TABLE via (
	id SERIAL PRIMARY KEY);

CREATE TABLE segmento_via (
	id_via INTEGER REFERENCES via(id),
	indice INTEGER NOT NULL,
	do_ponto VARCHAR(5) REFERENCES ponto(nome),
	ao_ponto VARCHAR(5) REFERENCES ponto(nome),
	CONSTRAINT segmento_via_pk PRIMARY KEY(id_via,indice,do_ponto,ao_ponto)
	);

-- dados de via
INSERT INTO via VALUES(DEFAULT);

-- dados de ponto
INSERT INTO ponto VALUES ('A',ST_GeomFromText('POINT(0 0)'));
INSERT INTO ponto VALUES ('B',ST_GeomFromText('POINT(1 1)'));
INSERT INTO ponto VALUES ('C',ST_GeomFromText('POINT(-1 -1)'));
INSERT INTO ponto VALUES ('D',ST_GeomFromText('POINT(-1 1)'));
INSERT INTO ponto VALUES ('E',ST_GeomFromText('POINT(1 -1)'));

-- dados de segmento_via
INSERT INTO segmento_via VALUES (1,0,'A','B');
INSERT INTO segmento_via VALUES (1,1,'B','C');
INSERT INTO segmento_via VALUES (1,2,'C','D');
```

* Neste caso temos: ```via``` que é uma coleção de segmentos, ```segmento_via``` que é formada por dois pontos, ```do_ponto``` até ```ao_ponto```;

* A única tabela que temos geometria é a tabela de pontos. Da mesma conseguimos derivar todo o resto (geometria de segmento_via e geometria de via);

* Criaremos views para resolver as duas coisas acima:

```sql
SELECT
	id_via,
	indice,
	do_ponto,
	ao_ponto,
	ST_MakeLine(pt1.geom,pt2.geom) as "linha",
	ST_AsText(ST_MakeLine(pt1.geom,pt2.geom)) as "linha_texto"
FROM segmento_via sv
INNER JOIN ponto pt1 ON (sv.do_ponto = pt1.nome)
INNER JOIN ponto pt2 ON (sv.ao_ponto = pt2.nome)
```

* Teste a query acima. Ela reflete o dado mais atual da segmento_via. Ao criarmos uma view temos estes dados dinâmicos.

```sql
CREATE OR REPLACE VIEW segmento_via_geom AS
SELECT
	id_via,
	indice,
	do_ponto,
	ao_ponto,
	ST_MakeLine(pt1.geom,pt2.geom) as "linha",
	ST_AsText(ST_MakeLine(pt1.geom,pt2.geom)) as "linha_texto"
FROM segmento_via sv
INNER JOIN ponto pt1 ON (sv.do_ponto = pt1.nome)
INNER JOIN ponto pt2 ON (sv.ao_ponto = pt2.nome)
```

* Temos nossos segmentos. Precisamos agrupar os dados para obter a via completa.

```sql
SELECT
	id_via as "id",
	ST_Collect("linha")
FROM segmento_via_geometria
GROUP BY id_via
```

* Agora finalizamos e embrulhamos este sql em uma view

```sql
CREATE OR REPLACE VIEW via_geometria
SELECT
	id_via as "id",
	ST_Collect("linha")
FROM segmento_via_geometria
GROUP BY id_via
```

* Caso esteja preocupado com desempenho, transforme as views em funções plpgsql, trabalhando em cima de uma via apenas;

* Aqui conseguimos desonerar a aplicação e o desenvolvimento criando uma regra simples. A única coisa que a aplicação tem que considerar é a ordem dos segmentos na tabela ```segmento_via```. Se fossemos desenvolver a lógica para renderizar e criar estes segmentos em outras linguagens perderíamo tempo e estaríamos propensos ao erro.

---

# Criação de schemas de aplicação

* Não deixe seus dados no *schema* public;

* Existem dificuldades para migrar as versões do PostGIS, já que o *schema* public armazena os dados e funções do mesmo;

* Na hora de subir novas versões existirão conflitos;