# George Rodrigues da Cunha Silva

# Geográfo

* Formado desde 2008, pela UFU (Universidade Federal de Uberlândia);

* Sempre trabalhou com GIS. Proprietário e Open-source;

* Pira no tal do PostGIS;

* Ajuda a escrever a FOSSGISBrasil;

* Minor contributer PostGIS;

---

# Consultor

* Consultoria a grandes empresas e projetos (direta e indireta)

	* Força Aérea Brasileira;

	* INCRA;

	* SABESP;

	* COPASA;

	* Prefeituras (Manaus, Porto Velho, Contagem, entre outras);

---

# Contatos

* Email: georger.silva@gmail.com

* facebook: george.silva.gis

* twitter: georgersilva