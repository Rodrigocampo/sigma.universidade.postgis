Curso PostGIS
=============

-------------
Bem-vindo
-------------

Este é o repositório do curso de PostGIS. Através deste site trocaremos exemplos de código, delegaremos exercícios
aos alunos e receberemos respostas dos mesmos.

O GitHub é "a rede social nerd", feita para compartilhar código e ajudar desenvolvedores a... desenvolver.

Aproveite, é uma grande ferramenta.

-------------
Estrututa
-------------

Temos que ter um pouco de estrutura.

Na wiki estarão diversas referências a coisas legais e importantes durante o curso. Uma delas é a lista de links, download,
requisitos, etc. Uma cópia da apresentação utilizada também estará na wiki para visualização online, no formato rst (reStructuredText);

No controle de código, teremos todos os exemplos do curso, em formato sql, para fácil visualização e testes.

Ocasionalmente teremos na wiki parte do código, parecido com isto:

```sql
CREATE TABLE public.ponto_interesse (
id SERIAL PRIMARY KEY,
nome varchar(64) UNIQUE
);

-- adicionar coluna geométrica
SELECT AddGeometryColumn('public','ponto_interesse','geometria',4674,'POINT',2);
-- SELECT AddGeometryColumn('public','ponto_interesse','geometria',4674,'POINT',3);
```

A idéia principal é que este código, quando seja apenas de um teste ad-hoc, esteja junto com outros em um único arquivo .sql.

Caso seja um exercício maior, ele estará em seu próprio arquivo .sql. De toda forma, a idéia é que ele esteja na wiki e no
controle de código.

Dúvidas
-------------

Mande-as para: georger.silva@gmail.com

Índice
-------------


### [[Pré-requisitos|Pré-requisitos]]
### [[Links importantes|Links Importantes]]
### [[Instrutor|Instrutor]]
### [[Cronograma|Cronograma]]
### [[Como usar o git?|Como usar o git]]
### [[Ementa|Ementa]]
### [[Dados|Dados]]
### [[Aula 01 - Instalação|aula01]]
### [[Aula 02 - Baby Steps|aula02]]
### [[Aula 03 - Funções Geoespaciais|aula03]]
### [[Aula 04 - Experiência de Mundo Real|aula04]]
### [[Exercícios Gerais|exercicios_curso]]