Como usar o git?
=================================================

# O que é git?
-------------------------------------------------

git é uma ferramenta de controle de versão de código.
Você já usou SVN? git é uma versão mais inteligente do SVN.

# Pra que usaremos isso?
-------------------------------------------------

Usaremos o git para controlar as versões e resoluções dos exercícios
dos alunos.

Você clona meu repositório, faz exercício na sua pastinha especial e pede para que eu integre as mudanças que você fez, ao meu código,
ou seja, ao repositório central.

# O que o git pode fazer por mim?
-------------------------------------------------

Através do git, determinamos repositórios. Dentro de cada
repositório, definimos arquivos (principalmente arquivos texto puro)
para ele ficar de olho.

A partir deste momento, qualquer alteração no arquivo é gravada pelo git de forma transparente. Ele não interefere em nada no modo
de trabalho usual.

Os benefícios que o git trazem são:

* Permite que múltiplos autores trabalhem com os mesmos arquivos e
permite a resolução de conflitos de forma fácil.

* Permite que criemos __branches__ sem copiar o código completo. Criamos branches para implementar coisas novas ou não impactar no branch principal e assim que estiver tudo redondo, integramos os dois.

* Histórico. Você pode olhar TODAS as alterações que foram feitas no arquivo desde o dia que ele entrou para o controle de versão.

# SVN x git
-------------------------------------------------

* Repositório centralizado X Repositórios;

* Facilidade merge;

# Como usar?

## Clonar
-------------------------------------------------

A etapa de clonar é uma das mais usadas por todos.
Através dela copiamos tudo que existe em um repositório para outro
repositório, desconectado.

### Uso

```shell
git clone endereço [diretorio]
```

## Comitar mudanças
-------------------------------------------------

### Uso

```shell
git commit -m "mensagem"
```

## Enviar mudanças ao servidor
-------------------------------------------------

## Reconciliar (merge)

## Remover arquivos do controle de versão

## Adicionar arquivos ao controle de versão